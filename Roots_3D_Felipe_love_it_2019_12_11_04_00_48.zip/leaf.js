function Leaf() {
  this.pos = createVector(random(100,width-100), random(height/2+70,height/2+100), random(-100,100));
  this.reached = false;

  this.show = function() {
    fill(255);
    noStroke();
    push();
    translate(this.pos.x,this.pos.y,this.pos.z);
   // sphere(1);
    //ellipse(0, 0, 2, 4);
    pop();
  }
this.showEnergy = function() {
    fill(255,0,0, random(20,210));
    noStroke();
    push();
    translate(this.pos.x,this.pos.y,this.pos.z);
   // sphere(1);
    ellipse(0, 0, random(1,3), random(1,4));
    pop();
  }
}