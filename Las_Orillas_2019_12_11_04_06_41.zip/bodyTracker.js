/*
DInda 2019
Residencia Las Orillas
Museo Nacional de Calcos y Escultura Comparada Ernesto de La Cárcova
Raíces, Más allá del Límite
*/
/* Esta obra de arte forma parte de la investigación en la que se desarrollará un software con Aprendizaje automático (Tensorflow.js) y se visualizará en 3D en el navegador (P5.js) para detectar árboles e interactuar con las raíces a traves de realidad aumentada */ 
/* This work of art is part of the research in which software will be developed with automatic learning (Tensorflow.js) and will be displayed in 3D in the browser (P5.js) to detect trees and interact with the roots through augmented reality */

/*Physics engine - The nature of the code. Roots Growing thanks to Shiffman Daniel, Coding Challenge on The Coding Train!*/


/* Thanks to my dear husband whom I love so much! */

/*0 nose
1 leftEye
2 rightEye
3 leftEar
4 rightEar
5 leftShoulder
6 rightShoulder
7 leftElbow
8 rightElbow
9 leftWrist
10  rightWrist
11  leftHip
12  rightHip
13  leftKnee
14  rightKnee
15  leftAnkle
16  rightAnkle*/
var poseNet;
var video;

function BodyTracker() {
  this.noseX = 0;
  this.noseY = 0;
  this.leftShoulderX = 0;
  this.leftShoulderY = 0;
  this.rightShoulderX = 0;
  this.rightShoulderY = 0;
  this.leftWristX = 0;
  this.leftWristY = 0;
  this.rightWristX = 0;
  this.rightWristY = 0;
  this.leftHipX = 0;
  this.leftHipY = 0;
  this.rightHipX = 0;
  this.rightHipY = 0;
  this.chest = createVector(0, 0);

  this.displayVideo = function() {
    
   
    
    image(video, 0, 0); //display in canvas
//  ,width, width * video.height / video.width
  }

  this.displayBodyTrack = function() {
    stroke(255);
    noFill();
    ellipse(this.noseX, this.noseY, 30);
    ellipse(this.leftShoulderX, this.leftShoulderY, 30);
    ellipse(this.rightShoulderX, this.rightShoulderY, 30);
    ellipse(this.rightWristX, this.rightWristY, 30);
    ellipse(this.leftWristX, this.leftWristY, 30);
    ellipse(this.leftHipX, this.leftHipY, 30);
    ellipse(this.rightHipX, this.rightHipY, 30);

  }

  this.calculateBeginFlow = function() {
    
    //calculo X Chest
    let leftShoulder = createVector(this.leftShoulderX, this.leftShoulderY);
    let rightShoulder = createVector(this.rightShoulderX, this.rightShoulderY);
    let subVector = p5.Vector.sub(leftShoulder, rightShoulder);
    
    let result = subVector.x / 2 + rightShoulder.x; //x coordenada chest

    //calculo altura de hombro mas alta
    if (this.leftShoulderY > this.rightShoulderY) {
      subVector.y += this.rightShoulderY;
    } else {
      subVector.y += this.leftShoulderY;
    }
    //nuevo vector con el medio del pecho
    this.chest = createVector(result, subVector.y);
    //noFill();
    stroke(random(160,220),random(10,160),random(20,10),random(20,160));
    ellipse(this.chest.x, this.chest.y, random(10,20),random(20,30));
    
    return this.chest;

  }
  this.createVectors = function() { 
    let nose = createVector(this.noseX, this.noseY);
    let leftShoulder = createVector(this.leftShoulderX, this.leftShoulderY);
    let rightShoulder = createVector(this.rightShoulderX, this.rightShoulderY);
    let leftWrist = createVector(this.leftWristX, this.leftWristY);
    let rightWrist = createVector(this.rightWristX, this.rightWristY);
    let leftHip = createVector(this.leftHipX, this.leftHipY);
    let rightHip = createVector(this.rightHipX, this.rightHipY);

    let bodyTracking = [nose,leftShoulder,rightShoulder,leftWrist,rightWrist,leftHip,rightHip];    
    return bodyTracking;
  }

  this.bodyArray = function() {
    let bodyArrayUpdated = this.createVectors();
    return bodyArrayUpdated;
  }


  this.modelReady = function() {
    //  console.log('model ready');
  }

}