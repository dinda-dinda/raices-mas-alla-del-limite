function NeuralNetwork() {
  this.hidden_nodes=28
  this.createModel();



  function createModel() {

  this.model = tf.sequential();
    const hidden = tf.layers.dense


  }
  
  function fitModel(){
  
  
  
  
  
  
  
  }
  
  function predict(input){
  
  let predictThis = input;
  
    
  let output = [];
  
  
  }
  

  return output;
}