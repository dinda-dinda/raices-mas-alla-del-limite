/*
DInda 2019
Residencia Las Orillas
Museo Nacional de Calcos y Escultura Comparada Ernesto de La Cárcova
Raíces, Más allá del Límite
*/
/* Esta obra de arte forma parte de la investigación en la que se desarrollará un software con Aprendizaje automático (Tensorflow.js) y se visualizará en 3D en el navegador (P5.js) para detectar árboles e interactuar con las raíces a traves de realidad aumentada */ 
/* This work of art is part of the research in which software will be developed with automatic learning (Tensorflow.js) and will be displayed in 3D in the browser (P5.js) to detect trees and interact with the roots through augmented reality */

/*Physics engine - The nature of the code. Roots Growing thanks to Shiffman Daniel, Coding Challenge on The Coding Train!*/


/* Thanks to my dear husband whom I love so much! */

function Node(centerX,centerY) {
  
  this.pos = createVector(random(centerX+200,centerX-200), random(centerY,centerY+200)); //this -100 in(random(centerX+200,centerX-200), random(centerY,centerY+200)) Z to 1 its a valid option
  this.reached = false;


  this.show = function() {
    fill(255,10,200);
    noStroke();
    push();
  //  translate(random(centerX+200,centerX-200), random(centerY-100,centerY+200));
    translate(this.pos.x,this.pos.y);
    pop();
  }
this.showEnergy = function() {
    fill(255,0,0, random(20,210));
    noStroke();
    push();
    translate(this.pos.x,this.pos.y);
    ellipse(0, 0, random(1,3), random(1,4));
    pop();
  }
}