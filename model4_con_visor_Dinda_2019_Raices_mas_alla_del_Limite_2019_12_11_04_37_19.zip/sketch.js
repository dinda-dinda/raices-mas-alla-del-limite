let model;
let model1;


let xs;
let train_xs;
let train_ys;
let inAndOut;

let resolution = 20;
let cols;
let rows;

var ins;
var outs;
var batchSize;

var nn; // start a new file with the nn and other with the visor

var surface;

var surface1;
var surface2;

var surface3;

var historyLoss = [];

function setup() {
  createCanvas(400, 400);

  ins = new Inputs13(); // ins.pixels;
  outs = new Outputs13(); // outs.coords;
  inAndOut = new InputsAndOutputsToTest();

 
  /// visualization
  tfvis.visor();
  
  ///crear modelo
  model = tf.sequential();

  let hidden = tf.layers.dense({
    inputShape: [28, 28],
    units: 28,
    activation: 'relu'
  });

  let between = tf.layers.dense({
    units: 9,
    activation: 'softmax'
  });

  let output = tf.layers.dense({
    inputShape: [6],
    units: 6,
    activation: 'sigmoid'
  });
  


  const flattenLayer = tf.layers.flatten();

  model.add(hidden);
  model.add(flattenLayer);
  model.add(between);
  model.add(output);

  const optimizer = tf.train.adam(0.1);

  model.compile({
    loss: 'categoricalCrossentropy',
    optimizer: 'rmsprop',
    metrics: ['accuracy']
  })

   surface = { name: 'Layer Summary', tab: 'Model Inspection'};
   tfvis.show.layer(surface, model.getLayer(undefined, 1));


 
  
 
 
  surface2 = { name: 'Model Summary', tab: 'Model Inspection' };



  /*-----------Data to train---------------*/



  batchSize = 2;

  tfvis.show.modelSummary(surface2, model);

  xs = tf.tensor3d(inAndOut.pixelsToTest, [batchSize, 28, 28]);

  //console.log('xs');
  //console.log(xs);
  //xs.print();

  //entrena modelo
  setTimeout(train, 10);

  /*-------------End of Setup-------------------------------------------*/
}


//promesa, llama a entrenar modelo y muestra de losss
function train() {
  console.log("im in train!");
  trainModel().then(result => {
    console.log(result);
    setTimeout(train, 50);
  });

}

// entrena modelo~ params = train_xs(input) y train_ys(output)
async function trainModel() {

    //visor
    batchSize = 1;
    //Create the input data
    for (let i = 0; i < 5; i++) {
      train_xs = tf.tensor3d(ins.pixels[i], [batchSize, 28, 28], 'int32'); //[tens], [shape]
      train_ys = tf.tensor2d(outs.coords2[i], [batchSize, 6], 'int32');


      /*--------Fitness Model!----*/
   surface3 = { name: 'show.history', tab: 'Training' };

      const h = await model.fit(train_xs, train_ys, {
          epochs: 5
         
          }); 
        console.log("Loss after Epoch " + i + " : " + h.history.loss[0]);

        tfvis.show.history(surface3, h, ['loss', 'acc']);

      }
      // console.log('end fitness model');
    }


   function onBatchEnd(batch, logs) {
  console.log('Accuracy', logs.acc);
}

    //muestra visual!
    function draw() {
      background(220);

      //Get the predictions params xs = inputs para pruebas
      /* tf.tidy(() => {
    let ys = model.predict(xs);
    //console.log("ys");
    //console.log(ys);

    let y_values = ys.dataSync();
    //  console.log("y_values");
    // console.log(y_values);

  });

*/
    }