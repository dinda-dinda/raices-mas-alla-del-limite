/*
DInda 2019
Residencia Las Orillas
Museo Nacional de Calcos y Escultura Comparada Ernesto de La Cárcova
Raíces, Más allá del Límite
*/
/* Esta obra de arte forma parte de la investigación en la que se desarrollará un software con Aprendizaje automático (Tensorflow.js) y se visualizará en 3D en el navegador (P5.js) para detectar árboles e interactuar con las raíces a traves de realidad aumentada */ 
/* This work of art is part of the research in which software will be developed with automatic learning (Tensorflow.js) and will be displayed in 3D in the browser (P5.js) to detect trees and interact with the roots through augmented reality */

/*Physics engine - The nature of the code. Roots Growing thanks to Shiffman Daniel, Coding Challenge on The Coding Train!*/


/* Thanks to my dear husband whom I love so much! */


function Flow(x, y, m,type) {
  this.pos = createVector(x, y);
  this.acc = createVector(0, 0);
  this.vel = createVector(0, 0);
  this.maxspeed = 10;
  this.maxforce = 3;
  this.r = int(random(6,2));
  this.color = type;
  this.mass = m;
  m = random(10, 1);
 
  //newtons 2nd law: F = M * A or A = F/ M

  this.applyForce = function(force) {
    var f = p5.Vector.div(force, this.mass);
    this.acc.add(f); //add to acc
  }

  /* mira la posicion de los de alrededor para redifinir su steering*/
  this.separation = function(flows) {

    var desiredseparation = this.r * 6;
    var sum = createVector();
    var count = 0;
    // For every boid in the system, check if it's too close
    
    for (var i = 0; i < flows.length; i++) {
      var d = p5.Vector.dist(this.pos, flows[i].pos);
      
      // If the distance is greater than 0 and less than an arbitrary amount (0 when you are yourself)
      if ((d > 0) && (d < desiredseparation)) {
        // Calculate vector pointing away from neighbor
        var diff = p5.Vector.sub(this.pos, flows[i].pos);
        diff.normalize();
        diff.div(d); // Weight by distance
        sum.add(diff);
        count++; // Keep track of how many
      }
    }
    // Average -- divide by how many
    if (count > 0) {
      sum.div(count);
      // Our desired vector is the average scaled to maximum speed
      sum.normalize();
      sum.mult(this.maxspeed);
      // Implement Reynolds: Steering = Desired - Velocity
      var steer = p5.Vector.sub(sum, this.vel);
      steer.limit(this.maxforce);
      this.applyForce(steer);
    }
  }

  this.seek = function(target) {
    var desired = p5.Vector.sub(target, this.pos);

    // The seek behavior!
    desired.setMag(this.maxspeed);

    // Steering formula
    var steering = p5.Vector.sub(desired, this.vel);
    steering.limit(this.maxforce);
    this.applyForce(steering);

  }

  this.update = function() {
    this.vel.add(this.acc);
    this.vel.limit(this.maxspeed);
    this.pos.add(this.vel);
    this.acc.set(0, 0); //acc back to 0, so can check if there is any forces

  }

  this.displayFlow = function() {
    // Draw a triangle rotated in the direction of velocity
    var theta = this.vel.heading() + PI / 2;
    noFill();
    if(this.color=="first"){
    stroke(random(200,220),random(10,60),random(100,200),random(200,60));//gold
    
    }
    if(this.color=="second"){
    stroke(random(180,100),random(10,60),random(220,200),random(200,60));//red
    
    }
    strokeWeight(1);
    push();
    translate(this.pos.x, this.pos.y);
    rotate(theta);
    /*beginShape();
    vertex(0, -this.r * 2);
    vertex(-this.r, this.r * 2);
    vertex(this.r, this.r * 2);
    endShape(CLOSE);*/
    ellipse(0, 0, this.r, this.r/2);
    pop();
  }

  // Wraparound
  this.borders = function() {
    if (this.pos.x < -this.r) this.pos.x = windowWidth + this.r;
    if (this.pos.y < -this.r) this.pos.y = windowHeight + this.r;
    if (this.pos.x > windowWidth + this.r) this.pos.x = -this.r;
    if (this.pos.y > windowHeight + this.r) this.pos.y = -this.r;
  }




}