/*
DInda 2019
Residencia Las Orillas
Museo Nacional de Calcos y Escultura Comparada Ernesto de La Cárcova
Raíces, Más allá del Límite
*/
/* Esta obra de arte forma parte de la investigación en la que se desarrollará un software con Aprendizaje automático (Tensorflow.js) y se visualizará en 3D en el navegador (P5.js) para detectar árboles e interactuar con las raíces a traves de realidad aumentada */ 
/* This work of art is part of the research in which software will be developed with automatic learning (Tensorflow.js) and will be displayed in 3D in the browser (P5.js) to detect trees and interact with the roots through augmented reality */

/*Physics engine - The nature of the code. Roots Growing thanks to Shiffman Daniel, Coding Challenge on The Coding Train!*/


/* Thanks to my dear husband whom I love so much! */

function Roots(posX, posY,follow) {
  this.center = createVector(posX,posY);
  this.nodes = [];
  this.branches = [];
  this.followThis = follow;

  for (let i = 0; i < 200; i++) {
    this.nodes.push(new Node(posX, posY));
  }

  let pos = createVector(posX, posY);
  let dir = createVector(0, 1);

  let root = new Branch(null, pos, dir);
  this.branches.push(root);
  let current = root;
  let found = false;


  while (!found) {
    for (let i = 0; i < this.nodes.length; i++) {
      let d = p5.Vector.dist(current.pos, this.nodes[i].pos);
      if (d < max_dist) {
        found = true;
      }
    }
    if (!found) {
      let branch = current.next();
      current = branch;
      this.branches.push(current);
    }
  }


  this.grow = function() {
    for (let i = 0; i < this.nodes.length; i++) {
      let node = this.nodes[i];
      let closestBranch = null;
      let record = max_dist;
      for (let j = 0; j < this.branches.length; j++) {
        let branch = this.branches[j];
        let d = p5.Vector.dist(node.pos, branch.pos);
        if (d < min_dist) {
          node.reached = true;
          closestBranch = null;
          break;
        } else if (d < record) {
          closestBranch = branch;
          record = d;
        }
      }

      if (closestBranch != null) {
        let newDir = p5.Vector.sub(node.pos, closestBranch.pos);
        newDir.normalize();
        closestBranch.dir.add(newDir);
        closestBranch.count++;
      }
    }

    for (let i = this.nodes.length - 1; i >= 0; i--) {
      if (this.nodes[i].reached) {
        this.nodes[i].pos.x += random(0, 1);
        this.nodes[i].pos.y += random(0, 1);
        this.nodes[i].showEnergy();
      }
    }

    for (let i = this.branches.length - 1; i >= 0; i--) {
      let branch = this.branches[i];
      if (branch.count > 0) {
        branch.dir.div(branch.count + 1);
        let rand = createVector(random(-0.3,0.3),random(-0.3,0.3));
        branch.dir.add(rand);
        this.branches.push(branch.next());
        branch.reset();
      }
    }
  }





  this.show = function() {
    for (let i = 0; i < this.nodes.length; i++) {
      this.nodes[i].show();
    }

    for (let i = 0; i < this.branches.length; i++) {
      let sw = map(i, 0, this.branches.length, 4, 0); //ancho de raices por el largo del array de branches, se pasa por parametro
      this.branches[i].show(sw);
    }

  }

}