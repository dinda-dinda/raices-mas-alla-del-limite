/*
DInda 2019
Residencia Las Orillas
Museo Nacional de Calcos y Escultura Comparada Ernesto de La Cárcova
Raíces, Más allá del Límite
*/
/* Esta obra de arte forma parte de la investigación en la que se desarrollará un software con Aprendizaje automático (Tensorflow.js) y se visualizará en 3D en el navegador (P5.js) para detectar árboles e interactuar con las raíces a traves de realidad aumentada */ 
/* This work of art is part of the research in which software will be developed with automatic learning (Tensorflow.js) and will be displayed in 3D in the browser (P5.js) to detect trees and interact with the roots through augmented reality */

/*Physics engine - The nature of the code. Roots Growing thanks to Shiffman Daniel, Coding Challenge on The Coding Train!*/


/* Thanks to my dear husband whom I love so much! */

function Clicker(){

  this.clicks = 1;

  this.a1x = 0;
  this.a1y = 0;
  this.a2x = 0;
  this.a2y = 0;
  this.a3x = 0;
  this.a3y = 0;

  this.b1x = 0;
  this.b1y = 0;
  this.b2x = 0;
  this.b2y = 0;
  this.b3x = 0;
  this.b3y = 0;


  this.drawPoints = function(cuantosArboles){
   
    ellipseMode(CENTER);

    strokeWeight(6);
  
    if(cuantosArboles==2){
     
  stroke(0,255,0);
  ellipse(this.a2x,this.a2y,5,5);

  stroke(0,255,0);
  ellipse(this.b2x,this.b2y,5,5);

      
  }
  }

 this.howManyClicks = function(cuantosArboles,nArbol){
    
      if (this.clicks === 1) {

        this.a2x = mouseX;
        this.a2y = mouseY;
        nArbol = 1; 
        this.clicks++;
      
      } else if (this.clicks === 2){
      
        this.b2x = mouseX;
        this.b2y = mouseY;
        nArbol = 2;
        //stages = 3;
        readyForRoots();
        
    }
   }
  

 /*this.coordsToSave = function(points){

    points = [
      createVector(this.a1x, this.a1y),
      createVector(this.a2x, this.a2y),
      createVector(this.a3x, this.a3y),

      createVector(this.b1x, this.b1y),
      createVector(this.b2x, this.b2y),
      createVector(this.b3x, this.b3y)
    ];
    return points
  }*/

   this.resetClicks = function(){

    this.a1x = 0;
    this.a1y = 0;
    this.a2x = 0;
    this.a2y = 0;
    this.a3x = 0;
    this.a3y = 0;

    this.b1x = 0;
    this.b1y = 0;
    this.b2x = 0;
    this.b2y = 0;
    this.b3x = 0;
    this.b3y = 0;

    this.clicks = 1;
  }
}