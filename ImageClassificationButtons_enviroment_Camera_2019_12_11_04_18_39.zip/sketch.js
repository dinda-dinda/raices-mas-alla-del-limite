var mobileNet;
var video;
var label = "";
var felipeButton;
var feliciaButton;
var federicaButton;
var trainButton;

function modelReady() {
  console.log("model is Ready!");
}

function videoReady() {
  console.log("the video is ready");
}

function whileTraining(loss) {
  if (loss == null) {
    console.log("training Complete");
    classifier.classify(gotResults);
  } else {
    console.log(loss);
  }
}

function gotResults(err, results) {
  if (err) {
    console.error(err);
  } else {
    console.log(results);
    label = results;
    classifier.classify(gotResults);

  }
}

function preload() {
   video = createCapture({
    audio: false,
    video: {
      facingMode: {
        exact: "environment"
      }
    }
  });
  mobileNet = ml5.featureExtractor('MobileNet', modelReady);
  classifier = mobileNet.classification(video, videoReady);
}

/*function imageReady(){
  image(tree,0,0,width,height); 
}
*/

function setup() {
  createCanvas(500, 500);
  video.hide();
  felipeButton = createButton("felipe");
  felipeButton.mousePressed(function() {
    classifier.addImage('felipe');
  });
  feliciaButton = createButton("felicia");
  feliciaButton.mousePressed(function() {
    classifier.addImage('felicia');
  });

  federicaButton = createButton("federica");
  federicaButton.mousePressed(function() {
    classifier.addImage('federica');
  });

  trainButton = createButton("train");
  trainButton.mousePressed(function() {
    classifier.train(whileTraining);
  });
  label="test";

}

function draw() {
  background(0);
  image(video, 0, 0, width, height - 60);
  fill(220);
  textSize(40);
  text(label, 10, height - 30);
}