/*
DInda 2019
Residencia Las Orillas
Museo Nacional de Calcos y Escultura Comparada Ernesto de La Cárcova
Raíces, Más allá del Límite
*/
/* Esta obra de arte forma parte de la investigación en la que se desarrollará un software con Aprendizaje automático (Tensorflow.js) y se visualizará en 3D en el navegador (P5.js) para detectar árboles e interactuar con las raíces a través de realidad aumentada */ 
/* This work of art is part of the research in which a software will be developed with automatic learning (Tensorflow.js) and will be displayed in 3D in the browser (P5.js) to detect trees and interact with the roots through augmented reality */

/*Physics engine - The nature of the code. Roots Growing thanks to Shiffman Daniel, Coding Challenge on The Coding Train!*/


/* Thanks to my dear husband whom I love so much! */


var stages = 1; //stage 0 question, stage 1 identify, stage 2 roots grown, stage 0 back

var roots1;
var roots2;
var clicker;

var target;
var cuantosArboles;


var r = 100;
var R = 150;
var tree;
var max_dist = 200;
var min_dist = 10;


var instruccion1, instruccion2;
var poseNet;
var video;
var spectator;
var nArbol;
var flows1 = [];
var flows2 = [];

var flow1Active = false;
var flow2Active = false;
var trees;
var target;

function setup() {
  trees = {
    first: 0,
    second: 0
  };

  nArbol = 1;

  createCanvas(windowWidth, windowHeight);
  background(0);
  clicker = new Clicker();
   video =  createCapture({
    audio: false,
    video: {
      facingMode: {
        exact: "environment"
      //exact: "user"
      }
    }
  });
  video.size(windowWidth, windowHeight);
  //video = createCapture(VIDEO, windowWidth, windowHeight); //video camera
  video.hide(); //hide the video
  //console.log(ml5); //ml5 loaded properly
  spectator = new BodyTracker();
  poseNet = ml5.poseNet(video, spectator.modelReady);
  poseNet.on('pose', gotPoses);
  }


function draw() {
    background(0);
  spectator.displayVideo();

  if (stages == 1) {
    cuantosArboles = 2;
    push();
    translate(-width / 2, -height / 2);
    clicker.drawPoints(cuantosArboles);
    pop();
  }

  if (stages == 2) {
    trees = {
      first: createVector(clicker.a2x, clicker.a2y),
      second: createVector(clicker.b2x, clicker.b2y)
    };

    roots1 = new Roots(trees.first.x, trees.first.y);
    roots2 = new Roots(trees.second.x, trees.second.y);
    stages = 3;
  }

  if (stages == 3) {
    roots1.show();
    roots2.show();
    roots1.grow();
    roots2.grow();

    spectator.calculateBeginFlow();
    target = createVector(spectator.chest.x, spectator.chest.y);
    stroke(random(160,220),random(10,160),random(20,10),random(20,160));
    ellipse(target.x, target.y, random(6,10),random(10,12));
    
   // fill(250, 128, 114); //salmon
   // ellipse(target.x, target.y, 10, 10);

    if (flow1Active == false || flow2Active == false) {
      checkingConnection();
    }
    if (flow1Active == true) {

      if(dist(target.x,target.y,trees.first.x,trees.first.y)>200){
      flows1 = [];
      flow1Active = false;
      return;
      
      }
      for (let i = 0; i < flows1.length; i++) {
        flows1[i].separation(flows1);
        flows1[i].seek(target);
        // Update and display
        flows1[i].update();
        flows1[i].displayFlow();
      }
    }
    if (flow2Active == true) {
      if(dist(target.x,target.y,trees.second.x,trees.second.y)>200){
      
        flows2 = [];
        flow2Active = false;
        
      return;
      }
      for (let i = 0; i < flows2.length; i++) {
        flows2[i].separation(flows2);
        flows2[i].seek(target);
        // Update and display
        flows2[i].update();
        flows2[i].displayFlow();
      }
    }
  }
  
  
  
  stroke(255);
   text("sobre las raíces-",20, windowHeight-30);
   text("-Dile a alguien que camine",20, windowHeight-50);
 
  text("Res. Las Orillas, DInda 2019",windowWidth-160, windowHeight-30);
  text("Raíces, más allá del Límite",windowWidth-160, windowHeight-50);
  
}

checkingConnection = function() {
  let person = spectator.bodyArray();
  let distanciaFirst = 1000;
  let distanciaSecond = 1000;

  for (let i = 0; i < person.length; i++) {
    distanciaFirst = dist(person[i].x, person[i].y, trees.first.x, trees.first.y);
    distanciaSecond = dist(person[i].x, person[i].y, trees.second.x, trees.second.y);

    if (distanciaFirst <= 100 && flow1Active == false) {
      flow1Active = true;
      let type = "first";
      createFlow(type);
      return;
    }
    
    if (distanciaSecond <= 100 && flow2Active == false) {
      flow2Active = true;
      let type = "second";
      createFlow(type);
      return;
    }
  }
}

createFlow = function(tree) {
  let typeOfTree = tree;
  if (typeOfTree == "first") {
  let l = 0;
    for (let i = 0; i < 20; i++) {      
      l = new Flow(trees.first.x, trees.first.y, random(2, 4),typeOfTree); 
      //create a new flow from the first tree
      flows1.push(l); //push it into the array of flows
    }
  }
  if (typeOfTree == "second") {
    let m = 0;
    for (let i = 0; i < 20; i++) {
      m = new Flow(trees.second.x, trees.second.y, random(2, 4),typeOfTree);
      //create a new flow from the second tree
      flows2.push(m); //push it into the array of flows2    
    }
  }
}



function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  // easycam.setViewport([0,0,windowWidth, windowHeight]);
}

function resetClicks() {
  if (stages == 1) {
    clicker.resetClicks();
  }
}

function readyForRoots() {
  if (stages == 1) {
    stages = 2;
  }
}

function mouseClicked() {
  if (stages == 1) {
    nArbol = clicker.howManyClicks(cuantosArboles, nArbol);
  }
}

gotPoses = function(poses) {
  if (poses.length > 0) {
    let newNoseX = int(poses[0].pose.keypoints[0].position.x);
    let newNoseY = int(poses[0].pose.keypoints[0].position.y);
    let newLeftShoulderX = int(poses[0].pose.keypoints[5].position.x);
    let newLeftShoulderY = int(poses[0].pose.keypoints[5].position.y);
    let newRightShoulderX = int(poses[0].pose.keypoints[6].position.x);
    let newRightShoulderY = int(poses[0].pose.keypoints[6].position.y);
    let newLeftWristX = int(poses[0].pose.keypoints[9].position.x);
    let newLeftWristY = int(poses[0].pose.keypoints[9].position.y);
    let newRightWristX = int(poses[0].pose.keypoints[10].position.x);
    let newRightWristY = int(poses[0].pose.keypoints[10].position.y);
    let newLeftHipX = int(poses[0].pose.keypoints[11].position.x);
    let newLeftHipY = int(poses[0].pose.keypoints[11].position.y);
    let newRightHipX = int(poses[0].pose.keypoints[12].position.x);
    let newRightHipY = int(poses[0].pose.keypoints[12].position.y);


    spectator.noseX = lerp(spectator.noseX, newNoseX, 0.2);
    spectator.noseY = lerp(spectator.noseY, newNoseY, 0.2);
    spectator.leftShoulderX = lerp(spectator.leftShoulderX, newLeftShoulderX, 0.2);
    spectator.leftShoulderY = lerp(spectator.leftShoulderY, newLeftShoulderY, 0.2);
    spectator.rightShoulderX = lerp(spectator.rightShoulderX, newRightShoulderX, 0.2);
    spectator.rightShoulderY = lerp(spectator.rightShoulderY, newRightShoulderY, 0.2);
    spectator.leftWristX = lerp(spectator.leftWristX, newLeftWristX, 0.2);
    spectator.leftWristY = lerp(spectator.leftWristY, newLeftWristY, 0.2);
    spectator.rightWristX = lerp(spectator.rightWristX, newRightWristX, 0.2);
    spectator.rightWristY = lerp(spectator.rightWristY, newRightWristY, 0.2);
    spectator.leftHipX = lerp(spectator.leftHipX, newLeftHipX, 0.2);
    spectator.leftHipY = lerp(spectator.leftHipY, newLeftHipY, 0.2);
    spectator.rightHipX = lerp(spectator.rightHipX, newRightHipX, 0.2);
    spectator.rightHipY = lerp(spectator.rightHipY, newRightHipY, 0.2);

  }
}