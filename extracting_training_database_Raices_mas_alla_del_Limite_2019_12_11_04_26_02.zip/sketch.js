//Dinda 2019 - thedinda.art/raices
//este proceso fue desarrollado por DInda para "Raíces, 
//más allá del Límite" Proyecto de Investigación, Residencia Las Orillas.

//****antes de llegar al final guardar por error

//para guardar las coordenadas de la base del arbol y 
//los píxeles de las imágenes. input y output

//mover los puntos en las coordenadas
//rojo a la izquierda, verde al centro, azul a la derecha
//click en save data
//click en new img
//repetir hasta pasar por todas las imagenes

//exportar.



let a1x;
let a1y;
let a2x;
let a2y;
let a3x;
let a3y;

let btnSend;
let btnOther;
 let btnExport;
    
var img10, img11, img12, img13, img14, img15, img16,
    img17, img18, img19, img20, img21, img22, img23,
    img24, img25, img26, img27, img28, img29, img30,
    img31, img32, img33, img34, img35, img36, img37,
    img38, img39, img40, img41, img42, img43, img44,
    img45, img46, img47, img48, img49, img50, img51,
    img52;

let ys = [];

let xsImgs = [];
let imgs = [];
let dragg = false;
let infoSent= false;

function preload(){
   img10 = loadImage('img/10.jpg');
   img11 = loadImage('img/11.jpg');
   img12 = loadImage('img/12.jpg');
   img13 = loadImage('img/13.jpg');
   img14 = loadImage('img/14.jpg');
   img15 = loadImage('img/15.jpg');
   img16 = loadImage('img/16.jpg');
   img17 = loadImage('img/17.jpg');
   img18 = loadImage('img/18.jpg');
   img19 = loadImage('img/19.jpg');
   img20 = loadImage('img/20.jpg');
   img21 = loadImage('img/21.jpg');
   img22 = loadImage('img/22.jpg');
   img23 = loadImage('img/23.jpg');
   img24 = loadImage('img/24.jpg');
   img25 = loadImage('img/25.jpg');
   img26 = loadImage('img/26.jpg');
   img27 = loadImage('img/27.jpg');
   img28 = loadImage('img/28.jpg');
   img29 = loadImage('img/29.jpg');
   img30 = loadImage('img/30.jpg');
   img31 = loadImage('img/31.jpg');
   img32 = loadImage('img/32.jpg');
   img33 = loadImage('img/33.jpg');
   img34 = loadImage('img/34.jpg');
   img35 = loadImage('img/35.jpg');
   img36 = loadImage('img/36.jpg');
   img37 = loadImage('img/37.jpg');
   img38 = loadImage('img/38.jpg');
   img39 = loadImage('img/39.jpg');
   img40 = loadImage('img/40.jpg');
   img41 = loadImage('img/41.jpg');
   img42 = loadImage('img/42.jpg');
   img43 = loadImage('img/43.jpg');
   img44 = loadImage('img/44.jpg');
   img45 = loadImage('img/45.jpg');
   img46 = loadImage('img/46.jpg');
   img47 = loadImage('img/47.jpg');
   img48 = loadImage('img/48.jpg');
   img49 = loadImage('img/49.jpg');
   img50 = loadImage('img/50.jpg');
   img51 = loadImage('img/51.jpg');

}

function setup() {
  createCanvas(150, 320);
  background(100);
  a1x = 30;
  a1y = 160;
  a2x = 60;
  a2y = 160;
  a3x = 90;
  a3y = 160;
  
  btnSend = createVector(90,200);
  btnOther = createVector(90,250);
  btnExport = createVector(90,300);
  
  imgs = [img10, img11, img12, img13, img14, img15, img16,
    img17, img18, img19, img20, img21, img22, img23,
    img24, img25, img26, img27, img28, img29, img30,
    img31, img32, img33, img34, img35, img36, img37,
    img38, img39, img40, img41, img42, img43, img44,
    img45, img46, img47, img48, img49, img50, img51,
    img52];
  
  imgNumber = 0;
}



function draw() {

  
  background(100);
  //sent info
  fill(255);
  ellipse(btnSend.x,btnSend.y,20,40);
  text("save data",btnSend.x,btnSend.y);
  
  //new img
  fill(25);
  ellipse(btnOther.x,btnOther.y,20,40);
  text("new img",btnOther.x,btnOther.y);
  if(imgNumber==40){
   //btnExport
  fill(255,0,0);
  }else{fill(200),
   ellipse(btnExport.x, btnExport.y,20,40);
  text("Export",btnExport.x,btnExport.y);
       }
  if(imgNumber<=imgs.length){
  image(imgs[imgNumber], 0, 0);
  }else{
  console.log( "Exportando");
  exportData();
  }
  
    noStroke();
  fill(255,0,0);
  ellipse(a1x,a1y,5);
  fill(0,255,0);
  ellipse(a2x,a2y,5);
  fill(0,0,255);
  ellipse(a3x,a3y,5);
  
  checkingCoords();
  
  
}

function displayImg(){
 resetPoints();
 image(imgs[imgNumber], 0, 0);
 
  
}
function getImgPix(){
  let savingPxImage = [];
  
  loadPixels();
  //img.pixels.length= 22650
  for(let y= 0; y< 150 ;y++){
    for(let x= 0; x < width ;x++){
    savingPxImage.push(pixels[x+y*width]);
  
    }
  }
  xsImgs.push(savingPxImage);

}

function checkingCoords(){

   if (mouseIsPressed && dragg == false) {
       if(int(dist(mouseX, mouseY, a1x, a1y)<10)){
         a1x = mouseX;
         a1y = mouseY;
         dragg1 = true;
       }
       if (int(dist(mouseX, mouseY, a2x, a2y)<10)){
         a2x = mouseX;
         a2y = mouseY;
         dragg2 = true;
       }
      if (int(dist(mouseX, mouseY, a3x, a3y)<10)){
         a3x = mouseX;
         a3y = mouseY;
         dragg3 = true;
       }
      if(int(dist(mouseX, mouseY, btnSend.x,btnSend.y)<20)&&infoSent==false){
       /*console.log("save coords");
       console.log("a1 = ["+a1x+","+a1y+"]");
       console.log("a2 = ["+a2x+","+a2y+"]");
       console.log("a3 = ["+a3x+","+a3y+"]");*/
        
        let coordsToSave = [[a1x,a1y],[a2x,a2y],[a3x,a3y]];
        ys.push(coordsToSave); 
        
         image(imgs[imgNumber], 0, 0);
      
        infoSent= true;
        getImgPix();
        
       } 
      if(int(dist(mouseX, mouseY, btnOther.x,btnOther.y)<20)&&infoSent==true){
         
        resetPoints();
        imgNumber++;        
       } 
      if(int(dist(mouseX, mouseY, btnExport.x,btnExport.y)<20)&&infoSent==true){
         
        
        console.log("n de imagen" + imgNumber);   
        exportData();
          
       } 
     
  } else { dragg = false;
  }

}



function resetPoints(){
   
a1x = 30;
  a1y = 160;
  a2x = 60;
  a2y = 160;
  a3x = 90;
  a3y = 160;
  
  infoSent= false;
}

function exportData(){

  let outputs = JSON.stringify(ys);
  let inputs = JSON.stringify(xsImgs);

  download(outputs,'outputs1.txt', 'text/plain');
  download(inputs,'inputs1.txt', 'text/plain');

console.log("Data Exportada");
}

function download(content, fileName, contentType) {
    var a = document.createElement("a");
    var file = new Blob([content], {type: contentType});
    a.href = URL.createObjectURL(file);
    a.download = fileName;
    a.click();
  
  
}