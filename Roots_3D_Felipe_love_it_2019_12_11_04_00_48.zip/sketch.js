let felipe;
let easycam; 
let r =100;
let R = 150;
var tree;
var max_dist = 200;
var min_dist = 10;
 
var feli;

function preload(){
feli = loadImage('Felipe2.jpg');
}
function setup() { 
  createCanvas(400, 400,WEBGL); 
  setAttributes('antialias', true);
  
  
  easycam = createEasyCam({distance:500});
 
  document.oncontextmenu = function() { return false; }
  document.onmousedown   = function() { return false; }
  easycam = new Dw.EasyCam(this._renderer, {distance : 220}); 
  
   tree = new Tree();
}

function draw() {
  background(0);
  
/*  for(let i=0;i<2;i++){ 
    drawFace(i); 
  }*/
   noStroke();
  texture(feli);

  plane(200,200);

  translate(-width/2,-height/2,0);
  
  tree.show();
  tree.grow();
}


function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  easycam.setViewport([0,0,windowWidth, windowHeight]);
}
/*
function drawFace(j){
  fill(255,50);
  stroke(255); 
  beginShape(); 
  for(let i=0;i<4;i++){ 
    let ang = radians(i*360/4);
    let x = r*cos(ang);
    let y = r*sin(ang);
    let z = 100*j;
    vertex(x,y,z); 
  }
  endShape(CLOSE);
}*/